import React, { useState } from 'react';

function checkout() {
    //checkoutRedirect just to test out button
    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    const Isbn = urlParams.get('isbn')

    // const dataForQuery = [isbn]
    const [cardID, setCardID] = useState('CardID'); //CardID is originally set to empty

    const handleSubmit = (event) => {
        if (event && event.preventDefault) {
            event.preventDefault();
            setCardID(event.target.value)
            //append cardId to dataForQuery (POST)
            //execute INSERT query
            let date = new Date();
            let day = date.getDate();
            let month = date.getMonth() + 1;
            let year = date.getFullYear();

            let currentDate = `${year}-${month}-${day}`;
            let dueDate = `${year}-${month}-${day + 14}`

            const postData = {
                cardid: cardID,
                isbn: Isbn,
                current_date: currentDate,
                due_date : dueDate
            };

            axios
            .post(`books/checkout/${isbn}`,postData) // send isbn and book name
            .then((response) => {
            if (response.data.status) {
                setBooks(response.data.data);
            } else {
                console.log(response.data)
            }
            })
            .catch((error) => {
            console.log("An error occurred:", error.response);
            });

            console.log(cardID)
        }
      };
    
    return (
        <section>
            <div className="container">
                <h1 className = "mt-5"></h1>
                <form action="/checkoutRedirect">
                    <div className="form-group form-inline">     
                        <label htmlFor="CardID">CardID:</label>
                        <input type="text" name="CardID" className="form-control"/> 
                    </div>
                    <input type="submit" value="Submit" className="btn btn-primary mb-2" onClick={handleSubmit(this)} />
                </form>
            </div>
        </section>
    )
}

export default checkout;