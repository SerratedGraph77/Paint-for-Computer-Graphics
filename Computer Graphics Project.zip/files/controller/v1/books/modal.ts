export interface Book {
    bookId: number;
    isbn: string;
    title: string;
};

export interface Loan{
    cardId: string;
    isbn: string;
    Date_out: string;
    Due_date: string;
};

