export const BooksQueries = {
  GetBooks: `
    SELECT 
      bookId,
      isbn,
      title
    FROM 
      books
    WHERE 
      title LIKE ? `,
  InsertLoan: 
    `INSERT INTO book_loans (Card_id, isbn, Date_out, Due_date)
    VALUES (?,?,?,?)`,
  UpdateLoan: 
    `UPDATE book_Loans
    SET
      Date_in = ?
    Where
    Loan_id = ?`,
  SelectLoans:
    `DECLARE @b_name varchar(255)
    SET @b_name = ?
    SELECT * FROM book_Loans 
    WHERE
      Isbn (bookid) = ?
      OR
      Cardid = ?
      OR
    borrower.bname Like '%'+@b_name+'%';`
};

