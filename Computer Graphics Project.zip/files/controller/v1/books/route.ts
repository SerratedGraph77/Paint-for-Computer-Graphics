import express, { Router } from 'express';
import BooksController from './controller';

const booksRoutes: Router = express.Router();

//* Books *//
// /:bookName = the endpoint being defined, BooksController.getBooksByName = func called when visited
booksRoutes.get('/:bookName', BooksController.getBooksByName); //Returns book data
booksRoutes.post('/checkout/:isbn', BooksController.insertLoan); 
export default booksRoutes;


