import React, {useState } from 'react';
function checkin() {
    const [search, setSearch] = useState([]);
    const [bookId, setBookId] = useState('');
    const [cardNo, setCardNo] = useState('');
    const [bName, setBName] = useState('');
    const [record, setRecord] = useState([]);
    const [results, setResults] = useState([]);

    // Create Query based on items within search tuple

    var bTuple = ['lId','Isbn','card_d', 'date_out', 'due_date', 'date_in']
    var bTuple2 = ['lId2', 'Isbn2', 'card_d2', 'date_out2', 'due_date2', 'date_in2']
    var twoD = [bTuple, bTuple2]  
    
    

    const handleSubmit = (event) => {
        event.preventDefault();
        setSearch([bookId, cardNo, bName])
        //make query with search elements as parameters
        //setResults(response.data)
    }

    const handleCheckin = (event, tuple) => {
        event.preventDefault();
        //add today's date for check in attribute
        let date = new Date();

        let day = date.getDate();
        let month = date.getMonth() + 1;
        let year = date.getFullYear();
        let currentDate = `${year}-${month}-${day}`;
        let dueDate = `${year}-${month}-${day+14}`;
        tuple[4] = currentDate;
        tuple[5] = dueDate;
        setRecord(tuple)
        // Execute put request with contents of tuple as parameters
    }

    return (
        <section>
            <form onSubmit={handleSubmit} >
                <div>
                    <label htmlFor="book-id">Book Id:</label>
                    <input type="search" id="book-id" name="bookid" onChange={(event) => setBookId(event.target.value) } />
                    <label htmlFor="card-no">Card Id</label>
                    <input type="search" id="card-no" name="cardno" onChange={(event) => setCardNo(event.target.value) }/>
                    <label htmlFor="borrower-name">Borrower Name:</label>
                    <input type="search" id="borrower-name" name="borrwername" onChange={(event) => setBName(event.target.value) }/>
                </div>
                <button type="submit">Submit</button>
            </form>
            {
                results.length >= 0 ?   //change when query is implemented
                <div>
                    <table className="table">
                        <thead>
                            <tr>
                                <th scope="col">Index</th>
                                <th scope="col">Loan_id</th>
                                <th scope="col">Isbn</th>
                                <th scope="col">card_id</th>
                                <th scope="col">Date_out</th>
                                <th scope="col">Due_date</th>
                                <th scope="col">Date_in</th>
                                <th scope="col">Check In</th>
                            </tr>
                        </thead>
                        <tbody>
                            {twoD.map((cell, index) => ( // change twoD.map to results.map when query is implemented
                                <tr><td>{index}</td>
                                    <td>{cell[0]}</td>
                                    <td>{cell[1]}</td>
                                    <td>{cell[2]}</td>
                                    <td>{cell[3]}</td>
                                    <td>{cell[4]}</td>
                                    <td>{cell[5]}</td>
                                    <td><button id="checkinbtn" onClick={(event) => { handleCheckin(event, cell) }}>Check In</button></td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div> : <div></div>
            }
            <text>{record}</text>
            <text>{search}</text>
            
        </section>
    )
}

export default checkin