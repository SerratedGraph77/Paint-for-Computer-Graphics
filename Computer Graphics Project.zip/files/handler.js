const express = require('express');
const router = express.Router();
const pool = require('../config/db.js');
let repeater = 1
var error = 1;

router.get('/borrowerManagement', async (req, res) => {
    pool.getConnection((err, conn) => {
        if (err) throw err;

        try {
            const qry = `SELECT u.id,u.ssn, u.first_name, u.last_name, u.email, u.address, u.city, u.state, u.phone FROM borrowers as u INNER JOIN borrowers`;
            conn.query(qry, (err, result) => {
                conn.release();
                if (err) throw err;
                res.send(JSON.stringify(result));
            });
        } catch (err) {

            console.log(err);
            res.end();
        }
    });
    
});

router.post('/addBorrower', async (req, res) => {
   
    
    var ssn = req.body.ssnInput; 
    var first_name = req.body.fnameInput;
    var last_name = req.body.lnameInput;
    var email = req.body.emailInput
    var address = req.body.addressInput
    var city = req.body.cityInput
    var state = req.body.stateInput
    var phone = req.body.phoneInput

    pool.getConnection((err, conn) => {
        
        const ssn_checker = conn.query(`SELECT ssn FROM borrowers WHERE ssn = ?`, [ssn], function (err, row){
            if (err) 
            {
                console.log(err);
                res.end();
                return;
            } else 
            {
                if (row && row.length)
                {   
                    
                    error = 0;
                    //res.redirect('/borrowerManagement');
                    //res.end();
                    //return;
                }
                else
                {
                    
                    repeater++;
                    
                }
            }
        })
        
        if (repeater < 10)
        {
            id = "ID00000" + repeater;
        }
        else if (repeater < 100)
        {
            id = "ID0000" + repeater;
        }
        else if (repeater < 1000)
        {
            id = "ID000" + repeater;
        }
        else if (repeater < 10000)
        {
            id = "ID00" + repeater;
        }
        else if (repeater < 100000)
        {
            id = "ID0" + repeater;
        }
        else
        {
            id = "ID" + repeater;
        }
        const qry = `INSERT INTO borrowers(id, ssn, first_name, last_name, email, address, city, state, phone) VALUES(?,?,?,?,?,?,?,?,?)`;
        if (error == 1)
        {
            conn.query(qry, [id, ssn, first_name, last_name, email, address, city, state, phone], (err, result) => {
                conn.release();
                if (!err) {
                    console.log('borrower added');
                    res.redirect('/borrowerManagement');
                    res.end();
                }
            });
        }
        else 
        {
            console.log('Error! User is already a borrower');
            res.redirect('/borrowerManagement'); 
            res.end();
            error = false;
            }
        });        
    })


module.exports = router;