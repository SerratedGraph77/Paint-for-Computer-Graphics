import React from 'react';

function Home() {
    return (
        <section>
            <div className="container-fluid">
                <h1 className="mt-5">Welcome</h1>
                <p>This site was created using Node JS and React</p>
            </div>
        </section>
    );
}

export default Home;