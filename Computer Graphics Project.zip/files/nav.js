import React from 'react';
import { Link } from 'react-router-dom';

function Nav() {
    return (
        <nav className="navbar navbar-expand-lg navbar-light bg-dark top">
            <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navMainMenu" aria-controls="navMainMenu" aria-expanded="false" aria-label="Toggle navigation">
                <span className="navbar-toggler-icon"></span>
            </button>
            <div id="navMainMenu" className="navbar-collapse collapse">
                <div className="navbar-nav ml-auto">
                    <Link to='/' className="nav-item nav-link active"> Home </Link>
                    <Link to='/Search' className="nav-item nav-link active"> Search </Link>
                    <Link to='/borrowerManagement' className="nav-item nav-link active"> BorrowerManagement </Link>
                    <Link to='/checkin' className="nav-item nav-link active"> Checkin </Link>
                </div>
            </div>
        </nav>
    );
}

export default Nav;