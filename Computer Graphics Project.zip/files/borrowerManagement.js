import React, { useEffect, useState } from 'react';


function BorrowerManangement() {
    useEffect(() => {
        fetchItems();
    });

    const [items, setItems] = useState([]);

    const fetchItems = async () => {    //updates items
        const data = await fetch('/borrowermanagement'); //returns the response object when /borrowermanagement is visited
        const items = await data.json(); //sets items to the items variable to the json conversion of response object
        setItems(items);        //updates items to the arg of setItems
    };

    return (
        <section>
            <div className="container">
                <h1 className = "mt-5"></h1>
                <form method="POST" action="/addBorrower">
                    <div className="form-group form-inline">     
                        <label htmlFor="ssn"><span>Ssn:</span></label>
                        <input type="text" name="ssnInput" className="form-control" />    
                        <label htmlFor="first_name"><span>First Name:</span></label>
                        <input type="text" name="fnameInput" className="form-control" />
                        <label htmlFor="last_name"><span>Last Name:</span></label>
                        <input type="text" name="lnameInput" className="form-control" />
                        <label htmlFor="email"><span>Email:</span></label>
                        <input type="text" name="emailInput" className="form-control" />
                        <label htmlFor="address"><span>Address:</span></label>
                        <input type="text" name="addressInput" className="form-control" />
                        <label htmlFor="city"><span>City:</span></label>
                        <input type="text" name="cityInput" className="form-control" />
                        <label htmlFor="state"><span>State:</span></label>
                        <input type="text" name="stateInput" className="form-control" />
                        <label htmlFor="phone"><span>Phone:</span></label>
                        <input type="text" name="phoneInput" className="form-control" />
                    </div>
                    <input type="submit" value="Submit" className="btn btn-primary mb-2" />
                </form>
            </div>
        </section>
    );
}

export default BorrowerManangement;