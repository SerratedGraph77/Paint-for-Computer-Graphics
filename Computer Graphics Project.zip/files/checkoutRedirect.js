
function checkoutRedirect() {
    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    const card_id = urlParams.get('CardID')
    console.log(card_id)
    
    // Create/Send query to insert new record into book loans

    return (
        // Section tag used to contain multiple headers/footers, div tag allows for css styling
        <section> 
            <h1>
                <form method='post'> 
                    <div>
                        <text>{card_id}</text>
                    </div>
                </form>
            </h1>
        </section>
    )
}

export default checkoutRedirect;