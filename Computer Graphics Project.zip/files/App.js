//import logo from './logo.svg';
import './App.css';
import Nav from "./components/nav";
import Home from "./components/home";
import SearchBar from "./components/searchBar";
import BorrowerManagement from "./components/borrowerManagement";
import Checkout from "./components/checkout";
import CheckoutRedirect from "./components/checkoutRedirect";
import Checkin from "./components/checkin";
import { BrowserRouter as Router, Routes, Route} from 'react-router-dom';

function App()
{
    return (
      <Router>     
        <div className="App">
              <Nav />
              <Routes>
                    <Route path="/" element={<Home />} />
                    <Route path="/Search" element={<SearchBar />} />    
                    <Route path="/BorrowerManagement" element ={<BorrowerManagement/>} />
                    <Route path="/checkout" element={<Checkout />} />
                    <Route path="/checkoutRedirect" element ={<CheckoutRedirect/>} />
                    <Route path="/checkin" element ={<Checkin/>} />
              </Routes>
        </div>
      </Router>
  );
}



export default App;
